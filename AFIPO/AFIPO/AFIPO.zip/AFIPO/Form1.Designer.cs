namespace AFIPO
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.SqFeetTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.PaintTimelbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.powderlbl = new System.Windows.Forms.Label();
            this.MillageTB = new System.Windows.Forms.TextBox();
            this.PartColorCombo = new System.Windows.Forms.ComboBox();
            this.CureTempTB = new System.Windows.Forms.TextBox();
            this.PartDescTB = new System.Windows.Forms.TextBox();
            this.PartNoCombo = new System.Windows.Forms.ComboBox();
            this.label96 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label92 = new System.Windows.Forms.Label();
            this.label91 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.FeetCB = new System.Windows.Forms.ComboBox();
            this.convspeedlbl = new System.Windows.Forms.Label();
            this.MinConvCB = new System.Windows.Forms.ComboBox();
            this.label192 = new System.Windows.Forms.Label();
            this.PoundsTB = new System.Windows.Forms.TextBox();
            this.label193 = new System.Windows.Forms.Label();
            this.MinPartsPerTB = new System.Windows.Forms.TextBox();
            this.label191 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.MinPiecesTB = new System.Windows.Forms.TextBox();
            this.label189 = new System.Windows.Forms.Label();
            this.PartdelCustButton = new System.Windows.Forms.Button();
            this.PartsUnSelectedCustList = new System.Windows.Forms.ListBox();
            this.PartaddCustButton = new System.Windows.Forms.Button();
            this.SpecialNotesTB = new System.Windows.Forms.TextBox();
            this.label208 = new System.Windows.Forms.Label();
            this.PartSaveButton = new System.Windows.Forms.Button();
            this.PartCancelButton = new System.Windows.Forms.Button();
            this.PartDelButton = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label194 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.REC2TB = new System.Windows.Forms.TextBox();
            this.AA2TB = new System.Windows.Forms.TextBox();
            this.FR2TB = new System.Windows.Forms.TextBox();
            this.KV2TB = new System.Windows.Forms.TextBox();
            this.label199 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label201 = new System.Windows.Forms.Label();
            this.label228 = new System.Windows.Forms.Label();
            this.REC1TB = new System.Windows.Forms.TextBox();
            this.AA1TB = new System.Windows.Forms.TextBox();
            this.FR1TB = new System.Windows.Forms.TextBox();
            this.KV1TB = new System.Windows.Forms.TextBox();
            this.label198 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.MaskTimeTB = new System.Windows.Forms.TextBox();
            this.PreMaskcb = new System.Windows.Forms.CheckBox();
            this.blowlbl = new System.Windows.Forms.Label();
            this.BlowCb = new System.Windows.Forms.CheckBox();
            this.SpotFaceTB = new System.Windows.Forms.TextBox();
            this.DotsTB = new System.Windows.Forms.TextBox();
            this.CapsQtyTB = new System.Windows.Forms.TextBox();
            this.PlugsQtyTB = new System.Windows.Forms.TextBox();
            this.label229 = new System.Windows.Forms.Label();
            this.label230 = new System.Windows.Forms.Label();
            this.label231 = new System.Windows.Forms.Label();
            this.label232 = new System.Windows.Forms.Label();
            this.PartsSelectedCustList = new System.Windows.Forms.ListBox();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Teal;
            this.groupBox2.Controls.Add(this.SqFeetTB);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.PaintTimelbl);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.powderlbl);
            this.groupBox2.Controls.Add(this.MillageTB);
            this.groupBox2.Controls.Add(this.PartColorCombo);
            this.groupBox2.Controls.Add(this.CureTempTB);
            this.groupBox2.Controls.Add(this.PartDescTB);
            this.groupBox2.Controls.Add(this.PartNoCombo);
            this.groupBox2.Controls.Add(this.label96);
            this.groupBox2.Controls.Add(this.label95);
            this.groupBox2.Controls.Add(this.label93);
            this.groupBox2.Controls.Add(this.label94);
            this.groupBox2.Controls.Add(this.label92);
            this.groupBox2.Controls.Add(this.label91);
            this.groupBox2.Location = new System.Drawing.Point(11, 24);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox2.Size = new System.Drawing.Size(568, 129);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Part Data";
            // 
            // SqFeetTB
            // 
            this.SqFeetTB.Location = new System.Drawing.Point(401, 93);
            this.SqFeetTB.Margin = new System.Windows.Forms.Padding(2);
            this.SqFeetTB.Name = "SqFeetTB";
            this.SqFeetTB.Size = new System.Drawing.Size(38, 20);
            this.SqFeetTB.TabIndex = 21;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(312, 98);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 13);
            this.label4.TabIndex = 20;
            this.label4.Text = "Sq Feet Per Part";
            // 
            // PaintTimelbl
            // 
            this.PaintTimelbl.AutoSize = true;
            this.PaintTimelbl.Location = new System.Drawing.Point(161, 99);
            this.PaintTimelbl.Name = "PaintTimelbl";
            this.PaintTimelbl.Size = new System.Drawing.Size(75, 13);
            this.PaintTimelbl.TabIndex = 19;
            this.PaintTimelbl.Text = "PartTimeLabel";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 99);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 13);
            this.label2.TabIndex = 17;
            this.label2.Text = "Est Paint Time Per Part";
            // 
            // powderlbl
            // 
            this.powderlbl.AutoSize = true;
            this.powderlbl.Location = new System.Drawing.Point(226, 69);
            this.powderlbl.Name = "powderlbl";
            this.powderlbl.Size = new System.Drawing.Size(69, 13);
            this.powderlbl.TabIndex = 16;
            this.powderlbl.Text = "PowderLabel";
            // 
            // MillageTB
            // 
            this.MillageTB.Location = new System.Drawing.Point(493, 65);
            this.MillageTB.Margin = new System.Windows.Forms.Padding(2);
            this.MillageTB.Name = "MillageTB";
            this.MillageTB.Size = new System.Drawing.Size(63, 20);
            this.MillageTB.TabIndex = 9;
            this.MillageTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // PartColorCombo
            // 
            this.PartColorCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.PartColorCombo.FormattingEnabled = true;
            this.PartColorCombo.Location = new System.Drawing.Point(64, 65);
            this.PartColorCombo.Margin = new System.Windows.Forms.Padding(2);
            this.PartColorCombo.Name = "PartColorCombo";
            this.PartColorCombo.Size = new System.Drawing.Size(88, 21);
            this.PartColorCombo.TabIndex = 6;
            this.PartColorCombo.ValueMember = "ID";
            this.PartColorCombo.SelectedIndexChanged += new System.EventHandler(this.PartColorCombo_SelectedIndexChanged);
            // 
            // CureTempTB
            // 
            this.CureTempTB.Location = new System.Drawing.Point(401, 65);
            this.CureTempTB.Margin = new System.Windows.Forms.Padding(2);
            this.CureTempTB.Name = "CureTempTB";
            this.CureTempTB.Size = new System.Drawing.Size(38, 20);
            this.CureTempTB.TabIndex = 8;
            this.CureTempTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // PartDescTB
            // 
            this.PartDescTB.Location = new System.Drawing.Point(64, 38);
            this.PartDescTB.Margin = new System.Windows.Forms.Padding(2);
            this.PartDescTB.Name = "PartDescTB";
            this.PartDescTB.Size = new System.Drawing.Size(492, 20);
            this.PartDescTB.TabIndex = 5;
            // 
            // PartNoCombo
            // 
            this.PartNoCombo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Append;
            this.PartNoCombo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.PartNoCombo.FormattingEnabled = true;
            this.PartNoCombo.Location = new System.Drawing.Point(64, 12);
            this.PartNoCombo.Margin = new System.Windows.Forms.Padding(2);
            this.PartNoCombo.Name = "PartNoCombo";
            this.PartNoCombo.Size = new System.Drawing.Size(166, 21);
            this.PartNoCombo.TabIndex = 1;
            this.PartNoCombo.ValueMember = "ID";
            this.PartNoCombo.SelectedIndexChanged += new System.EventHandler(this.PartNoCombo_SelectedIndexChanged);
            this.PartNoCombo.SelectedValueChanged += new System.EventHandler(this.PartNoCombo_SelectedValueChanged);
            this.PartNoCombo.Validated += new System.EventHandler(this.PartNoCombo_Validated);
            // 
            // label96
            // 
            this.label96.AutoSize = true;
            this.label96.Location = new System.Drawing.Point(4, 15);
            this.label96.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label96.Name = "label96";
            this.label96.Size = new System.Drawing.Size(46, 13);
            this.label96.TabIndex = 15;
            this.label96.Text = "Part No.";
            // 
            // label95
            // 
            this.label95.AutoSize = true;
            this.label95.Location = new System.Drawing.Point(4, 41);
            this.label95.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label95.Name = "label95";
            this.label95.Size = new System.Drawing.Size(57, 13);
            this.label95.TabIndex = 1;
            this.label95.Text = "Part Desc.";
            // 
            // label93
            // 
            this.label93.AutoSize = true;
            this.label93.Location = new System.Drawing.Point(452, 69);
            this.label93.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label93.Name = "label93";
            this.label93.Size = new System.Drawing.Size(40, 13);
            this.label93.TabIndex = 5;
            this.label93.Text = "Millage";
            // 
            // label94
            // 
            this.label94.AutoSize = true;
            this.label94.Location = new System.Drawing.Point(4, 69);
            this.label94.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label94.Name = "label94";
            this.label94.Size = new System.Drawing.Size(31, 13);
            this.label94.TabIndex = 2;
            this.label94.Text = "Color";
            // 
            // label92
            // 
            this.label92.AutoSize = true;
            this.label92.Location = new System.Drawing.Point(338, 69);
            this.label92.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label92.Name = "label92";
            this.label92.Size = new System.Drawing.Size(59, 13);
            this.label92.TabIndex = 4;
            this.label92.Text = "Cure Temp";
            // 
            // label91
            // 
            this.label91.AutoSize = true;
            this.label91.Location = new System.Drawing.Point(158, 69);
            this.label91.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label91.Name = "label91";
            this.label91.Size = new System.Drawing.Size(63, 13);
            this.label91.TabIndex = 6;
            this.label91.Text = "Powder No.";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.FeetCB);
            this.groupBox3.Controls.Add(this.convspeedlbl);
            this.groupBox3.Controls.Add(this.MinConvCB);
            this.groupBox3.Controls.Add(this.label192);
            this.groupBox3.Controls.Add(this.PoundsTB);
            this.groupBox3.Controls.Add(this.label193);
            this.groupBox3.Controls.Add(this.MinPartsPerTB);
            this.groupBox3.Controls.Add(this.label191);
            this.groupBox3.Controls.Add(this.label190);
            this.groupBox3.Controls.Add(this.MinPiecesTB);
            this.groupBox3.Controls.Add(this.label189);
            this.groupBox3.Location = new System.Drawing.Point(11, 157);
            this.groupBox3.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox3.Size = new System.Drawing.Size(568, 69);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Conveyor Data";
            // 
            // FeetCB
            // 
            this.FeetCB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.FeetCB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.FeetCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.FeetCB.FormattingEnabled = true;
            this.FeetCB.Location = new System.Drawing.Point(332, 13);
            this.FeetCB.Margin = new System.Windows.Forms.Padding(2);
            this.FeetCB.Name = "FeetCB";
            this.FeetCB.Size = new System.Drawing.Size(43, 21);
            this.FeetCB.TabIndex = 19;
            this.FeetCB.ValueMember = "ID";
            // 
            // convspeedlbl
            // 
            this.convspeedlbl.AutoSize = true;
            this.convspeedlbl.Location = new System.Drawing.Point(111, 43);
            this.convspeedlbl.Name = "convspeedlbl";
            this.convspeedlbl.Size = new System.Drawing.Size(0, 13);
            this.convspeedlbl.TabIndex = 18;
            this.convspeedlbl.Visible = false;
            // 
            // MinConvCB
            // 
            this.MinConvCB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.MinConvCB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.MinConvCB.DisplayMember = "SPEED";
            this.MinConvCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MinConvCB.FormattingEnabled = true;
            this.MinConvCB.Location = new System.Drawing.Point(113, 12);
            this.MinConvCB.Margin = new System.Windows.Forms.Padding(2);
            this.MinConvCB.Name = "MinConvCB";
            this.MinConvCB.Size = new System.Drawing.Size(39, 21);
            this.MinConvCB.TabIndex = 10;
            this.MinConvCB.ValueMember = "ID";
            // 
            // label192
            // 
            this.label192.AutoSize = true;
            this.label192.Location = new System.Drawing.Point(379, 40);
            this.label192.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label192.Name = "label192";
            this.label192.Size = new System.Drawing.Size(135, 13);
            this.label192.TabIndex = 8;
            this.label192.Text = "Pounds of Powder Per Part";
            // 
            // PoundsTB
            // 
            this.PoundsTB.Location = new System.Drawing.Point(332, 38);
            this.PoundsTB.Margin = new System.Windows.Forms.Padding(2);
            this.PoundsTB.Name = "PoundsTB";
            this.PoundsTB.Size = new System.Drawing.Size(44, 20);
            this.PoundsTB.TabIndex = 14;
            this.PoundsTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // label193
            // 
            this.label193.AutoSize = true;
            this.label193.Location = new System.Drawing.Point(236, 42);
            this.label193.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label193.Name = "label193";
            this.label193.Size = new System.Drawing.Size(99, 13);
            this.label193.TabIndex = 6;
            this.label193.Text = "Min Parts Per Rack";
            // 
            // MinPartsPerTB
            // 
            this.MinPartsPerTB.Location = new System.Drawing.Point(188, 37);
            this.MinPartsPerTB.Margin = new System.Windows.Forms.Padding(2);
            this.MinPartsPerTB.Name = "MinPartsPerTB";
            this.MinPartsPerTB.Size = new System.Drawing.Size(44, 20);
            this.MinPartsPerTB.TabIndex = 13;
            this.MinPartsPerTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // label191
            // 
            this.label191.AutoSize = true;
            this.label191.Location = new System.Drawing.Point(379, 16);
            this.label191.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label191.Name = "label191";
            this.label191.Size = new System.Drawing.Size(28, 13);
            this.label191.TabIndex = 4;
            this.label191.Text = "Feet";
            // 
            // label190
            // 
            this.label190.AutoSize = true;
            this.label190.Location = new System.Drawing.Point(236, 18);
            this.label190.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label190.Name = "label190";
            this.label190.Size = new System.Drawing.Size(78, 13);
            this.label190.TabIndex = 2;
            this.label190.Text = "Min Pieces Per";
            // 
            // MinPiecesTB
            // 
            this.MinPiecesTB.Location = new System.Drawing.Point(188, 13);
            this.MinPiecesTB.Margin = new System.Windows.Forms.Padding(2);
            this.MinPiecesTB.Name = "MinPiecesTB";
            this.MinPiecesTB.Size = new System.Drawing.Size(44, 20);
            this.MinPiecesTB.TabIndex = 11;
            this.MinPiecesTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // label189
            // 
            this.label189.AutoSize = true;
            this.label189.Location = new System.Drawing.Point(4, 15);
            this.label189.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(106, 13);
            this.label189.TabIndex = 17;
            this.label189.Text = "Min Conveyor Speed";
            // 
            // PartdelCustButton
            // 
            this.PartdelCustButton.Location = new System.Drawing.Point(236, 471);
            this.PartdelCustButton.Margin = new System.Windows.Forms.Padding(2);
            this.PartdelCustButton.Name = "PartdelCustButton";
            this.PartdelCustButton.Size = new System.Drawing.Size(115, 19);
            this.PartdelCustButton.TabIndex = 17;
            this.PartdelCustButton.Text = "<- Delete Customer";
            this.PartdelCustButton.UseVisualStyleBackColor = true;
            this.PartdelCustButton.Click += new System.EventHandler(this.PartdelCustButton_Click);
            // 
            // PartsUnSelectedCustList
            // 
            this.PartsUnSelectedCustList.CausesValidation = false;
            this.PartsUnSelectedCustList.Location = new System.Drawing.Point(20, 411);
            this.PartsUnSelectedCustList.Margin = new System.Windows.Forms.Padding(2);
            this.PartsUnSelectedCustList.Name = "PartsUnSelectedCustList";
            this.PartsUnSelectedCustList.Size = new System.Drawing.Size(194, 108);
            this.PartsUnSelectedCustList.TabIndex = 15;
            // 
            // PartaddCustButton
            // 
            this.PartaddCustButton.Location = new System.Drawing.Point(236, 437);
            this.PartaddCustButton.Margin = new System.Windows.Forms.Padding(2);
            this.PartaddCustButton.Name = "PartaddCustButton";
            this.PartaddCustButton.Size = new System.Drawing.Size(115, 19);
            this.PartaddCustButton.TabIndex = 16;
            this.PartaddCustButton.Text = "Add Customer ->";
            this.PartaddCustButton.UseVisualStyleBackColor = true;
            this.PartaddCustButton.Click += new System.EventHandler(this.PartaddCustButton_Click);
            // 
            // SpecialNotesTB
            // 
            this.SpecialNotesTB.Location = new System.Drawing.Point(91, 540);
            this.SpecialNotesTB.Margin = new System.Windows.Forms.Padding(2);
            this.SpecialNotesTB.Name = "SpecialNotesTB";
            this.SpecialNotesTB.Size = new System.Drawing.Size(476, 20);
            this.SpecialNotesTB.TabIndex = 20;
            // 
            // label208
            // 
            this.label208.AutoSize = true;
            this.label208.Location = new System.Drawing.Point(15, 545);
            this.label208.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label208.Name = "label208";
            this.label208.Size = new System.Drawing.Size(73, 13);
            this.label208.TabIndex = 19;
            this.label208.Text = "Special Notes";
            // 
            // PartSaveButton
            // 
            this.PartSaveButton.Location = new System.Drawing.Point(90, 564);
            this.PartSaveButton.Margin = new System.Windows.Forms.Padding(2);
            this.PartSaveButton.Name = "PartSaveButton";
            this.PartSaveButton.Size = new System.Drawing.Size(56, 19);
            this.PartSaveButton.TabIndex = 21;
            this.PartSaveButton.Text = "Save";
            this.PartSaveButton.UseVisualStyleBackColor = true;
            this.PartSaveButton.Click += new System.EventHandler(this.PartSaveButton_Click);
            // 
            // PartCancelButton
            // 
            this.PartCancelButton.Location = new System.Drawing.Point(276, 565);
            this.PartCancelButton.Margin = new System.Windows.Forms.Padding(2);
            this.PartCancelButton.Name = "PartCancelButton";
            this.PartCancelButton.Size = new System.Drawing.Size(56, 19);
            this.PartCancelButton.TabIndex = 23;
            this.PartCancelButton.Text = "Cancel";
            this.PartCancelButton.UseVisualStyleBackColor = true;
            this.PartCancelButton.Click += new System.EventHandler(this.PartCancelButton_Click);
            // 
            // PartDelButton
            // 
            this.PartDelButton.Location = new System.Drawing.Point(185, 564);
            this.PartDelButton.Margin = new System.Windows.Forms.Padding(2);
            this.PartDelButton.Name = "PartDelButton";
            this.PartDelButton.Size = new System.Drawing.Size(56, 19);
            this.PartDelButton.TabIndex = 22;
            this.PartDelButton.Text = "Delete";
            this.PartDelButton.UseVisualStyleBackColor = true;
            this.PartDelButton.Click += new System.EventHandler(this.PartDelButton_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label194);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.REC2TB);
            this.groupBox5.Controls.Add(this.AA2TB);
            this.groupBox5.Controls.Add(this.FR2TB);
            this.groupBox5.Controls.Add(this.KV2TB);
            this.groupBox5.Controls.Add(this.label199);
            this.groupBox5.Controls.Add(this.label200);
            this.groupBox5.Controls.Add(this.label201);
            this.groupBox5.Controls.Add(this.label228);
            this.groupBox5.Controls.Add(this.REC1TB);
            this.groupBox5.Controls.Add(this.AA1TB);
            this.groupBox5.Controls.Add(this.FR1TB);
            this.groupBox5.Controls.Add(this.KV1TB);
            this.groupBox5.Controls.Add(this.label198);
            this.groupBox5.Controls.Add(this.label197);
            this.groupBox5.Controls.Add(this.label196);
            this.groupBox5.Controls.Add(this.label195);
            this.groupBox5.Location = new System.Drawing.Point(11, 248);
            this.groupBox5.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox5.Size = new System.Drawing.Size(568, 72);
            this.groupBox5.TabIndex = 13;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Powder Gun Settings";
            // 
            // label194
            // 
            this.label194.AutoSize = true;
            this.label194.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label194.Location = new System.Drawing.Point(5, 14);
            this.label194.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label194.Name = "label194";
            this.label194.Size = new System.Drawing.Size(33, 13);
            this.label194.TabIndex = 30;
            this.label194.Text = "Gun1";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.Desktop;
            this.label12.Location = new System.Drawing.Point(304, 14);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(33, 13);
            this.label12.TabIndex = 29;
            this.label12.Text = "Gun2";
            // 
            // REC2TB
            // 
            this.REC2TB.Location = new System.Drawing.Point(502, 48);
            this.REC2TB.Margin = new System.Windows.Forms.Padding(2);
            this.REC2TB.Name = "REC2TB";
            this.REC2TB.Size = new System.Drawing.Size(58, 20);
            this.REC2TB.TabIndex = 22;
            // 
            // AA2TB
            // 
            this.AA2TB.Location = new System.Drawing.Point(502, 26);
            this.AA2TB.Margin = new System.Windows.Forms.Padding(2);
            this.AA2TB.Name = "AA2TB";
            this.AA2TB.Size = new System.Drawing.Size(58, 20);
            this.AA2TB.TabIndex = 20;
            this.AA2TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // FR2TB
            // 
            this.FR2TB.Location = new System.Drawing.Point(364, 48);
            this.FR2TB.Margin = new System.Windows.Forms.Padding(2);
            this.FR2TB.Name = "FR2TB";
            this.FR2TB.Size = new System.Drawing.Size(59, 20);
            this.FR2TB.TabIndex = 21;
            this.FR2TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // KV2TB
            // 
            this.KV2TB.Location = new System.Drawing.Point(364, 26);
            this.KV2TB.Margin = new System.Windows.Forms.Padding(2);
            this.KV2TB.Name = "KV2TB";
            this.KV2TB.Size = new System.Drawing.Size(59, 20);
            this.KV2TB.TabIndex = 19;
            this.KV2TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // label199
            // 
            this.label199.AutoSize = true;
            this.label199.Location = new System.Drawing.Point(431, 48);
            this.label199.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label199.Name = "label199";
            this.label199.Size = new System.Drawing.Size(47, 13);
            this.label199.TabIndex = 12;
            this.label199.Text = "Receipe";
            // 
            // label200
            // 
            this.label200.AutoSize = true;
            this.label200.Location = new System.Drawing.Point(431, 28);
            this.label200.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label200.Name = "label200";
            this.label200.Size = new System.Drawing.Size(67, 13);
            this.label200.TabIndex = 8;
            this.label200.Text = "Atomizing Air";
            // 
            // label201
            // 
            this.label201.AutoSize = true;
            this.label201.Location = new System.Drawing.Point(304, 48);
            this.label201.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label201.Name = "label201";
            this.label201.Size = new System.Drawing.Size(55, 13);
            this.label201.TabIndex = 10;
            this.label201.Text = "Flow Rate";
            // 
            // label228
            // 
            this.label228.AutoSize = true;
            this.label228.Location = new System.Drawing.Point(304, 28);
            this.label228.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label228.Name = "label228";
            this.label228.Size = new System.Drawing.Size(57, 13);
            this.label228.TabIndex = 6;
            this.label228.Text = "KV Setting";
            // 
            // REC1TB
            // 
            this.REC1TB.Location = new System.Drawing.Point(199, 48);
            this.REC1TB.Margin = new System.Windows.Forms.Padding(2);
            this.REC1TB.Name = "REC1TB";
            this.REC1TB.Size = new System.Drawing.Size(58, 20);
            this.REC1TB.TabIndex = 18;
            // 
            // AA1TB
            // 
            this.AA1TB.Location = new System.Drawing.Point(199, 26);
            this.AA1TB.Margin = new System.Windows.Forms.Padding(2);
            this.AA1TB.Name = "AA1TB";
            this.AA1TB.Size = new System.Drawing.Size(58, 20);
            this.AA1TB.TabIndex = 16;
            this.AA1TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // FR1TB
            // 
            this.FR1TB.Location = new System.Drawing.Point(64, 49);
            this.FR1TB.Margin = new System.Windows.Forms.Padding(2);
            this.FR1TB.Name = "FR1TB";
            this.FR1TB.Size = new System.Drawing.Size(59, 20);
            this.FR1TB.TabIndex = 17;
            this.FR1TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // KV1TB
            // 
            this.KV1TB.Location = new System.Drawing.Point(64, 27);
            this.KV1TB.Margin = new System.Windows.Forms.Padding(2);
            this.KV1TB.Name = "KV1TB";
            this.KV1TB.Size = new System.Drawing.Size(59, 20);
            this.KV1TB.TabIndex = 15;
            this.KV1TB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // label198
            // 
            this.label198.AutoSize = true;
            this.label198.Location = new System.Drawing.Point(128, 48);
            this.label198.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label198.Name = "label198";
            this.label198.Size = new System.Drawing.Size(47, 13);
            this.label198.TabIndex = 4;
            this.label198.Text = "Receipe";
            // 
            // label197
            // 
            this.label197.AutoSize = true;
            this.label197.Location = new System.Drawing.Point(128, 28);
            this.label197.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(67, 13);
            this.label197.TabIndex = 1;
            this.label197.Text = "Atomizing Air";
            // 
            // label196
            // 
            this.label196.AutoSize = true;
            this.label196.Location = new System.Drawing.Point(4, 48);
            this.label196.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label196.Name = "label196";
            this.label196.Size = new System.Drawing.Size(55, 13);
            this.label196.TabIndex = 3;
            this.label196.Text = "Flow Rate";
            // 
            // label195
            // 
            this.label195.AutoSize = true;
            this.label195.Location = new System.Drawing.Point(4, 28);
            this.label195.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(57, 13);
            this.label195.TabIndex = 2;
            this.label195.Text = "KV Setting";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label1);
            this.groupBox11.Controls.Add(this.MaskTimeTB);
            this.groupBox11.Controls.Add(this.PreMaskcb);
            this.groupBox11.Controls.Add(this.blowlbl);
            this.groupBox11.Controls.Add(this.BlowCb);
            this.groupBox11.Controls.Add(this.SpotFaceTB);
            this.groupBox11.Controls.Add(this.DotsTB);
            this.groupBox11.Controls.Add(this.CapsQtyTB);
            this.groupBox11.Controls.Add(this.PlugsQtyTB);
            this.groupBox11.Controls.Add(this.label229);
            this.groupBox11.Controls.Add(this.label230);
            this.groupBox11.Controls.Add(this.label231);
            this.groupBox11.Controls.Add(this.label232);
            this.groupBox11.Location = new System.Drawing.Point(11, 324);
            this.groupBox11.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox11.Size = new System.Drawing.Size(568, 78);
            this.groupBox11.TabIndex = 14;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Masking";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(259, 50);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Mask Time Per Part";
            // 
            // MaskTimeTB
            // 
            this.MaskTimeTB.Location = new System.Drawing.Point(364, 43);
            this.MaskTimeTB.Margin = new System.Windows.Forms.Padding(2);
            this.MaskTimeTB.Name = "MaskTimeTB";
            this.MaskTimeTB.Size = new System.Drawing.Size(53, 20);
            this.MaskTimeTB.TabIndex = 9;
            // 
            // PreMaskcb
            // 
            this.PreMaskcb.AutoSize = true;
            this.PreMaskcb.Location = new System.Drawing.Point(145, 49);
            this.PreMaskcb.Name = "PreMaskcb";
            this.PreMaskcb.Size = new System.Drawing.Size(98, 17);
            this.PreMaskcb.TabIndex = 8;
            this.PreMaskcb.Text = "Pre Mask Parts";
            this.PreMaskcb.UseVisualStyleBackColor = true;
            // 
            // blowlbl
            // 
            this.blowlbl.AutoSize = true;
            this.blowlbl.Location = new System.Drawing.Point(134, 40);
            this.blowlbl.Name = "blowlbl";
            this.blowlbl.Size = new System.Drawing.Size(0, 13);
            this.blowlbl.TabIndex = 7;
            // 
            // BlowCb
            // 
            this.BlowCb.AutoSize = true;
            this.BlowCb.Location = new System.Drawing.Point(8, 49);
            this.BlowCb.Name = "BlowCb";
            this.BlowCb.Size = new System.Drawing.Size(118, 17);
            this.BlowCb.TabIndex = 4;
            this.BlowCb.Text = "Blow Excess Water";
            this.BlowCb.UseVisualStyleBackColor = true;
            // 
            // SpotFaceTB
            // 
            this.SpotFaceTB.Location = new System.Drawing.Point(364, 14);
            this.SpotFaceTB.Margin = new System.Windows.Forms.Padding(2);
            this.SpotFaceTB.Name = "SpotFaceTB";
            this.SpotFaceTB.Size = new System.Drawing.Size(53, 20);
            this.SpotFaceTB.TabIndex = 2;
            // 
            // DotsTB
            // 
            this.DotsTB.Location = new System.Drawing.Point(502, 15);
            this.DotsTB.Margin = new System.Windows.Forms.Padding(2);
            this.DotsTB.Name = "DotsTB";
            this.DotsTB.Size = new System.Drawing.Size(47, 20);
            this.DotsTB.TabIndex = 3;
            this.DotsTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // CapsQtyTB
            // 
            this.CapsQtyTB.Location = new System.Drawing.Point(201, 15);
            this.CapsQtyTB.Margin = new System.Windows.Forms.Padding(2);
            this.CapsQtyTB.Name = "CapsQtyTB";
            this.CapsQtyTB.Size = new System.Drawing.Size(44, 20);
            this.CapsQtyTB.TabIndex = 1;
            this.CapsQtyTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // PlugsQtyTB
            // 
            this.PlugsQtyTB.Location = new System.Drawing.Point(71, 15);
            this.PlugsQtyTB.Margin = new System.Windows.Forms.Padding(2);
            this.PlugsQtyTB.Name = "PlugsQtyTB";
            this.PlugsQtyTB.Size = new System.Drawing.Size(47, 20);
            this.PlugsQtyTB.TabIndex = 0;
            this.PlugsQtyTB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DotsTB_KeyPress);
            // 
            // label229
            // 
            this.label229.AutoSize = true;
            this.label229.Location = new System.Drawing.Point(142, 19);
            this.label229.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label229.Name = "label229";
            this.label229.Size = new System.Drawing.Size(50, 13);
            this.label229.TabIndex = 6;
            this.label229.Text = "Caps Qty";
            // 
            // label230
            // 
            this.label230.AutoSize = true;
            this.label230.Location = new System.Drawing.Point(303, 21);
            this.label230.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label230.Name = "label230";
            this.label230.Size = new System.Drawing.Size(56, 13);
            this.label230.TabIndex = 5;
            this.label230.Text = "Spot Face";
            // 
            // label231
            // 
            this.label231.AutoSize = true;
            this.label231.Location = new System.Drawing.Point(431, 19);
            this.label231.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label231.Name = "label231";
            this.label231.Size = new System.Drawing.Size(48, 13);
            this.label231.TabIndex = 4;
            this.label231.Text = "Dots Qty";
            // 
            // label232
            // 
            this.label232.AutoSize = true;
            this.label232.Location = new System.Drawing.Point(11, 19);
            this.label232.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label232.Name = "label232";
            this.label232.Size = new System.Drawing.Size(52, 13);
            this.label232.TabIndex = 3;
            this.label232.Text = "Plugs Qty";
            // 
            // PartsSelectedCustList
            // 
            this.PartsSelectedCustList.CausesValidation = false;
            this.PartsSelectedCustList.Location = new System.Drawing.Point(373, 411);
            this.PartsSelectedCustList.Margin = new System.Windows.Forms.Padding(2);
            this.PartsSelectedCustList.Name = "PartsSelectedCustList";
            this.PartsSelectedCustList.Size = new System.Drawing.Size(194, 108);
            this.PartsSelectedCustList.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(592, 608);
            this.Controls.Add(this.PartsSelectedCustList);
            this.Controls.Add(this.PartdelCustButton);
            this.Controls.Add(this.PartsUnSelectedCustList);
            this.Controls.Add(this.PartaddCustButton);
            this.Controls.Add(this.SpecialNotesTB);
            this.Controls.Add(this.label208);
            this.Controls.Add(this.PartSaveButton);
            this.Controls.Add(this.PartCancelButton);
            this.Controls.Add(this.PartDelButton);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox3);
            this.Name = "Form1";
            this.Text = "Parts";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label powderlbl;
        private System.Windows.Forms.TextBox MillageTB;
        private System.Windows.Forms.ComboBox PartColorCombo;
        private System.Windows.Forms.TextBox CureTempTB;
        private System.Windows.Forms.TextBox PartDescTB;
        private System.Windows.Forms.ComboBox PartNoCombo;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label convspeedlbl;
        private System.Windows.Forms.ComboBox MinConvCB;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.TextBox PoundsTB;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.TextBox MinPartsPerTB;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.TextBox MinPiecesTB;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Button PartdelCustButton;
        private System.Windows.Forms.Button PartaddCustButton;
        private System.Windows.Forms.TextBox SpecialNotesTB;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Button PartSaveButton;
        private System.Windows.Forms.Button PartCancelButton;
        private System.Windows.Forms.Button PartDelButton;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox REC2TB;
        private System.Windows.Forms.TextBox AA2TB;
        private System.Windows.Forms.TextBox FR2TB;
        private System.Windows.Forms.TextBox KV2TB;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.Label label228;
        private System.Windows.Forms.TextBox REC1TB;
        private System.Windows.Forms.TextBox AA1TB;
        private System.Windows.Forms.TextBox FR1TB;
        private System.Windows.Forms.TextBox KV1TB;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label blowlbl;
        private System.Windows.Forms.CheckBox BlowCb;
        private System.Windows.Forms.TextBox SpotFaceTB;
        private System.Windows.Forms.TextBox DotsTB;
        private System.Windows.Forms.TextBox CapsQtyTB;
        private System.Windows.Forms.TextBox PlugsQtyTB;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Label label230;
        private System.Windows.Forms.Label label231;
        private System.Windows.Forms.Label label232;
        private System.Windows.Forms.CheckBox PreMaskcb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox MaskTimeTB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label PaintTimelbl;
        private System.Windows.Forms.ComboBox FeetCB;
        private System.Windows.Forms.TextBox SqFeetTB;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.ListBox PartsUnSelectedCustList;
        public System.Windows.Forms.ListBox PartsSelectedCustList;
    }
}