using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using AFIObjects;

namespace AFIPO
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void button2_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Receiving";
        }

        private void button3_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Count Verification";
        }

        private void button4_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Shipping";
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Parts";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            //Colors
            Form8 f8 = new Form8();
            f8.ShowDialog();
        }

        private void button5_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Colors";
        }

        private void button6_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Customers";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            //Customers
            Form9 f9 = new Form9();
            f9.ShowDialog();
        }

        private void button7_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Reports";
        }

        private void button8_MouseEnter(object sender, EventArgs e)
        {
            label1.Text = "Shippers";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form11 f11 = new Form11();
            f11.ShowDialog();
        }
    }
}